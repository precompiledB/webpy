print(5 + 6)

a = 8

b = 9

def hello():
    print("hello")

print(a - b)

hello()
